# Guide de l'animateur : CardioScope

Workshop *Deep Learning for Cardiovascular Risk Detection*, BIOVANCE, samedi 26 septembre 2026, École Polytechnique de Sousse.
Les notebooks et l'application sont en anglais (langue de l'événement) ; ce guide est pour vous.

## 1. Avant le jour J

**J-3 / J-2**

1. Créer le dépôt GitHub `cardioscope-workshop` et y pousser ce dossier (sans `data/`).
   Remplacer `YOUR-ACCOUNT` par votre compte GitHub dans les deux notebooks et le README
   (VS Code : Ctrl+Maj+H, « Remplacer dans les fichiers »), puis relancer `python tools/build_notebooks.py`
   si vous modifiez le générateur plutôt que les notebooks.
2. Tester les deux notebooks dans Colab depuis une fenêtre de navigation privée avec un autre compte Google,
   une fois avec GPU T4 et une fois sans GPU. Noter les durées réelles d'entraînement.
3. Sur votre portable (RTX A5500) : `python scripts/prepare_data.py`, puis `python app.py`, et vérifier
   l'application sur les enregistrements 233, 232 et 219.
4. Plan B hors ligne sur clé USB et sur votre Google Drive : l'archive du dépôt et le ZIP officiel PhysioNet
   `mit-bih-arrhythmia-database-1.0.0.zip` (73,5 Mo, lien « Download the ZIP file » sur
   https://physionet.org/content/mitdb/1.0.0/).
5. Faire envoyer par les organisateurs le message de prérequis : ordinateur portable chargé, compte Google,
   navigateur récent, smartphone ; bases de Python ; aucune installation.

**J-1** : préparer un QR code vers le lien Colab de la partie 1, et vérifier le Wi-Fi de la salle.

**Jour J** : vidéoprojecteur HDMI, multiprises, votre portable avec l'application déjà lancée en local (secours).

## 2. Déroulé minuté et messages clés

Chiffres attendus avec les modèles fournis (entraînement CPU, graine 0). Sur GPU, un ou deux points d'écart
sont normaux.

### Partie 1 (9h00-11h00) : du signal ECG au diagnostic battement par battement

| Horaire | Séquence | À dire, à montrer |
|---|---|---|
| 9h00-9h15 | Ouverture | Les maladies cardiovasculaires sont la première cause de mortalité dans le monde (OMS). L'ECG est l'examen cardiaque le plus répandu et le moins cher ; l'IA en fait un biomarqueur (Hannun 2019 : détection d'arythmies au niveau des cardiologues ; Attia 2019 : dysfonction ventriculaire gauche). Quiz « humain contre IA » : projeter la bande de l'enregistrement 208 et faire voter la salle sur les battements anormaux. Présenter le fil rouge : construire CardioScope. |
| 9h15-9h35 | Lab 1 | Lancer la cellule de setup et le téléchargement dès la première minute. Classes AAMI, déséquilibre. Quiz : le modèle « toujours N » obtient 89 % d'accuracy et ne détecte aucun battement anormal. Conclusion : on parle désormais de sensibilité et de VPP par classe. |
| 9h35-10h00 | Lab 2 | Pendant l'entraînement (environ 3,5 min sur un cœur CPU, plus rapide sur T4) : ResNet 1D à 3 blocs, environ 125 000 paramètres, décalage aléatoire du pic R (augmentation), poids de classes. |
| 10h00-10h20 | Lab 3 | Le moment fort : 98,9 % d'accuracy sur les patients vus, 76,1 % sur les nouveaux (macro-F1 91,9 % contre 40,5 %). Le réseau a appris des patients, pas des arythmies. Règle : séparer par patient. |
| 10h20-10h50 | Lab 4 | Demander à la salle : « que regarde un cardiologue que notre CNN ignore ? ». Rythme : 78,2 % (macro-F1 44,6 %). Battement dominant du patient : 93,0 % (macro-F1 57,0 %), la VPP des ESV passe de 46 % à 91 %. Limites honnêtes : 232 (extrasystoles auriculaires majoritaires, bloc de branche droit) et 219 (fibrillation auriculaire). |
| 10h50-11h00 | Synthèse | Les trois messages de la matinée ; lancer le défi de la pause (changer un seul paramètre). |

### Partie 2 (14h00-15h30) : du modèle à l'outil clinique

| Horaire | Séquence | À dire, à montrer |
|---|---|---|
| 14h00-14h10 | Reprise | Si Colab a réinitialisé la machine, le notebook recharge les modèles fournis : personne ne reste bloqué. |
| 14h10-14h30 | Lab 5 | Calibration : une température ajustée sur les mêmes patients vaut environ 1 et ne change rien ; ajustée sur de nouveaux patients, elle vaut environ 2 à 2,4. Exemple du modèle « + rythme » : ECE de 14,5 % à 3,2 %. Triage au seuil 0,9 : 16 % des battements envoyés au cardiologue, avec 15 % d'erreurs, contre 4 % pour ceux que l'IA garde. Question à la salle : quel seuil pour un dépistage ? pour un service de nuit ? |
| 14h30-14h45 | Lab 6 | Grad-CAM : demander où regarde le modèle (onde P, largeur du QRS). Contre-factuel : si l'extrasystole auriculaire était arrivée à l'heure, la probabilité S s'effondre ; la décision repose sur le timing, comme chez le cardiologue. |
| 14h45-15h10 | Lab 7 + déploiement | Rapports Holter sans annotation : 100 (normal), 233 (charge en ESV 26,5 %, salves ventriculaires : risque élevé), 232 (pause de 5,9 s), 219 (fibrillation auriculaire : 73 % des battements signalés pour relecture, l'IA sait qu'elle ne sait pas). Lancer l'application, projeter le QR code du lien public, les participants testent sur smartphone. |
| 15h10-15h25 | Débat | Données (47 patients, Boston, 1975-1979), angles morts, réglementation (dispositif médical, AI Act, loi organique 2004-63 et INPDP en Tunisie), responsabilité humaine. |
| 15h25-15h30 | Clôture | Les trois messages, le lien du dépôt, pistes : ECG 12 dérivations (PTB-XL), validation externe. |

**Les trois messages à retenir (dernière diapositive)**

1. Évaluer par patient, jamais par battement.
2. Donner au modèle le contexte qu'utilise le clinicien : le rythme et le battement habituel du patient.
3. Une IA médicale utile sait dire « je ne sais pas » et laisse la décision au médecin.

## 3. Questions probables

* **« Les articles annoncent 99 %, pourquoi pas vous ? »** Beaucoup mélangent les battements d'un même patient
  entre entraînement et test : c'est exactement le piège du Lab 3.
* **« Pourquoi 180 Hz ? »** Après le filtre 0,5-40 Hz, 180 Hz respecte largement Nyquist et divise le calcul par deux.
* **« Pourquoi pas un Transformer ou un modèle plus gros ? »** Avec 22 patients d'entraînement, la limite est la
  diversité des patients, pas la capacité du modèle.
* **« Et sur ma montre connectée ? »** Autre dérivation (I au lieu de MLII), autre bruit, autre population :
  décalage de distribution, il faudrait une validation dédiée.
* **« Utilisable à l'hôpital ? »** Non : c'est un dispositif médical (validation clinique prospective,
  marquage CE ou FDA) et des données de santé protégées.

## 4. Plans B

| Problème | Solution |
|---|---|
| Pas de GPU sur Colab | Tout tourne sur CPU. Si c'est trop lent, mettre `EPOCHS = 4` dans la cellule de setup, ou charger un modèle fourni : `model_m, _ = load_checkpoint("checkpoints/cardionet_morph.pt", DEVICE)` (idem `rhythm`, `context`). |
| PhysioNet lent ou indisponible | Le code essaie aussi le miroir AWS de PhysioNet. Sinon : copier le ZIP officiel dans Colab (depuis votre Drive partagé) et exécuter `D.extract_mitdb_zip("mit-bih-arrhythmia-database-1.0.0.zip")`. |
| Colab saturé ou indisponible | Démonstration depuis votre portable : `jupyter lab` pour les notebooks, `python app.py --share` pour l'application ; les participants suivent à l'écran et testent l'application par le lien. |
| Lien public bloqué par le réseau | `python app.py --host 0.0.0.0` sur votre portable ; les participants du même Wi-Fi ouvrent `http://<adresse IP du portable>:7860`. |
